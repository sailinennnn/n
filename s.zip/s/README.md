# PYTHON3
SELF BOT PYTHON3.
------
-
Cara Install Self Bot :
------
- Ketik -> `apt update`
- Ketik -> `apt upgrade`
- Ketik -> `apt install git`
- Ketik -> `apt install python3-pip`
- Ketik -> `pip3 install rsa`
- Ketik -> `pip3 install thrift==0.11.0`
- Ketik -> `pip3 install requests`
- Ketik -> `pip3 install bs4`
- Ketik -> `pip3 install gtts`
- Ketik -> `pip3 install pytz`
- Ketik -> `pip3 install humanfriendly`
- Ketik -> `pip3 install googletrans`
- Ketik -> `git clone https://github.com/Nadyatjia/BotLinePython3`
- Ketik -> `cd BotLinePython3`
- Ketik -> `python3 Nadyasb.py`

Cara Menjalankan Bot Kembali :
------
- Ketik -> `cd LineBotPython3`
- Ketik -> `python3 Nadyasb.py`


Credit By@ Nadya Sutjiadi.
------
- `Follow My Instagram : nadya.tjia`
- `Add My ID LINE : nad_nad. (pake titik)`

Thx To :
------
- `LINE-TCR TEAM`
- `HELLO-WORLD`
